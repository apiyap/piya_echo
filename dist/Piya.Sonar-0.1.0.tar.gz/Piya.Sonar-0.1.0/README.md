# piya_echo
Ultrasonic HC-SR04 Sensor Python Library for Nvidia jetson nano

Please install  [jetson-gpio](https://github.com/NVIDIA/jetson-gpio) first.
